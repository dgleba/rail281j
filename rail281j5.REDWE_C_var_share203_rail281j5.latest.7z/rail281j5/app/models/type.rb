class Type < ActiveRecord::Base
end
